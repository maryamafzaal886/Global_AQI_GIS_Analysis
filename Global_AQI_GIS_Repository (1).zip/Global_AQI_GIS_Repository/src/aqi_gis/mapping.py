from pathlib import Path
import pandas as pd
import plotly.express as px
import pycountry

def iso3(country_name: str):
    """Best-effort country-name to ISO-3 conversion."""
    aliases = {
        "United States": "USA", "United States of America": "USA",
        "Russia": "RUS", "South Korea": "KOR", "North Korea": "PRK",
        "Vietnam": "VNM", "Iran": "IRN", "Syria": "SYR",
        "Taiwan": "TWN", "Bolivia": "BOL", "Tanzania": "TZA",
        "Moldova": "MDA", "Venezuela": "VEN", "Laos": "LAO",
        "Brunei": "BRN", "Czech Republic": "CZE", "Congo": "COG",
        "Democratic Republic of the Congo": "COD",
        "Ivory Coast": "CIV", "Cape Verde": "CPV",
    }
    if country_name in aliases:
        return aliases[country_name]
    try:
        return pycountry.countries.lookup(country_name).alpha_3
    except LookupError:
        return None

def create_latest_map(df: pd.DataFrame, output_path: str | Path) -> list[str]:
    latest_date = df["Date"].max()
    latest = df[df["Date"] == latest_date].copy()
    latest["iso3"] = latest["Country"].map(iso3)
    unmatched = sorted(latest.loc[latest["iso3"].isna(), "Country"].dropna().unique().tolist())
    mapped = latest.dropna(subset=["iso3"])

    if mapped.empty:
        raise ValueError("No country names could be matched to ISO-3 codes; map not created.")

    fig = px.choropleth(
        mapped, locations="iso3", color="AQI Value",
        hover_name="Country", hover_data={"iso3": False, "AQI Value": ":.1f", "Status": True},
        color_continuous_scale="RdYlGn_r",
        title=f"Country-level AQI — {latest_date:%Y-%m-%d}",
        projection="natural earth"
    )
    fig.update_layout(margin=dict(l=0, r=0, t=55, b=0))
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.write_html(output_path, include_plotlyjs="cdn")
    return unmatched
