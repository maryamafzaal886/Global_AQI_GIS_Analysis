"""Global AQI GIS analysis package."""
