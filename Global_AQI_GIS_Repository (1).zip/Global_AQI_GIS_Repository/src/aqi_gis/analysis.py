from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

def create_summaries(df: pd.DataFrame, output_dir: str | Path) -> None:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    country = (df.groupby("Country", as_index=False)
                 .agg(mean_aqi=("AQI Value", "mean"),
                      max_aqi=("AQI Value", "max"),
                      observations=("AQI Value", "size"))
                 .sort_values("mean_aqi", ascending=False))
    country.to_csv(output_dir / "country_aqi_summary.csv", index=False)

    daily = df.groupby("Date", as_index=False)["AQI Value"].mean()
    daily.to_csv(output_dir / "global_daily_mean_aqi.csv", index=False)

    status = df["Status"].value_counts(dropna=False).rename_axis("Status").reset_index(name="records")
    status.to_csv(output_dir / "status_counts.csv", index=False)

    # Top 15 country mean AQI
    top = country.head(15).sort_values("mean_aqi")
    fig, ax = plt.subplots(figsize=(10, 7))
    ax.barh(top["Country"], top["mean_aqi"])
    ax.set_title("15 Countries with Highest Mean AQI")
    ax.set_xlabel("Mean AQI")
    ax.set_ylabel("Country")
    fig.tight_layout()
    fig.savefig(output_dir / "top_15_country_mean_aqi.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(daily["Date"], daily["AQI Value"], linewidth=1)
    ax.set_title("Global Mean AQI Through Time")
    ax.set_xlabel("Date")
    ax.set_ylabel("Mean AQI")
    fig.tight_layout()
    fig.savefig(output_dir / "global_daily_mean_aqi.png", dpi=180)
    plt.close(fig)
