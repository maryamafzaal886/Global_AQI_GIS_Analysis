from pathlib import Path
import pandas as pd

COLUMN_ALIASES = {
    "date": "Date",
    "datetime": "Date",
    "country": "Country",
    "status": "Status",
    "aqi value": "AQI Value",
    "aqi_value": "AQI Value",
    "aqi": "AQI Value",
}

def load_and_clean(csv_path: str | Path) -> pd.DataFrame:
    """Load source CSV, normalize columns, validate records, aggregate by country/date."""
    df = pd.read_csv(csv_path)
    normalized = {c: COLUMN_ALIASES.get(str(c).strip().lower(), str(c).strip()) for c in df.columns}
    df = df.rename(columns=normalized)

    required = {"Date", "Country", "AQI Value"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}. Found: {list(df.columns)}")

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce", dayfirst=False)
    df["Country"] = df["Country"].astype("string").str.strip()
    df["AQI Value"] = pd.to_numeric(df["AQI Value"], errors="coerce")
    if "Status" not in df.columns:
        df["Status"] = pd.NA

    df = df.dropna(subset=["Date", "Country", "AQI Value"])
    df = df[(df["Country"] != "") & (df["AQI Value"] >= 0)].copy()
    df["Original Status"] = df["Status"]

    # EPA-style breakpoints for a consistent exploratory label; source labels are preserved above.
    def category(v):
        if v <= 50: return "Good"
        if v <= 100: return "Moderate"
        if v <= 150: return "Unhealthy for Sensitive Groups"
        if v <= 200: return "Unhealthy"
        if v <= 300: return "Very Unhealthy"
        return "Hazardous"

    out = (df.groupby(["Date", "Country"], as_index=False)
             .agg({"AQI Value": "mean", "Original Status": lambda x: x.dropna().mode().iloc[0] if not x.dropna().empty else pd.NA}))
    out["Status"] = out["AQI Value"].apply(category)
    out = out.sort_values(["Country", "Date"]).reset_index(drop=True)
    return out
